// services.js

import { find, create, findById } from '../models/Service';

// GET /api/services
export async function getServices(req, res, next) {
  try {
    const services = await find();
    res.json(services);
  } catch (error) {
    next(error);
  }
}

// POST /api/services
export async function createService(req, res, next) {
  try {
    const { name, description, price } = req.body;
    const service = await create({ name, description, price });
    res.json(service);
  } catch (error) {
    next(error);
  }
}

// GET /api/services/:id
export async function getServiceById(req, res, next) {
  try {
    const { id } = req.params;
    const service = await findById(id);
    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }
    res.json(service);
  } catch (error) {
    next(error);
  }
}
