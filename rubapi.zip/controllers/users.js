// users.js

import { create, findById } from '../models/User';

// POST /api/users
export async function createUser(req, res, next) {
  try {
    const { name, email, password } = req.body;
    const user = await create({ name, email, password });
    res.json(user);
  } catch (error) {
    next(error);
  }
}

// GET /api/users/:id
export async function getUserById(req, res, next) {
  try {
    const { id } = req.params;
    const user = await findById(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    next(error);
  }
}