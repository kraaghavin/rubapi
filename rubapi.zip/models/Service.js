import { Schema, model } from 'mongoose';

const serviceSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
  features: [{
    type: {
      type: String,
      enum: ['text', 'image', 'dropdown'],
      required: true,
    },
    label: {
      type: String,
      required: true,
    },
    options: [{
      type: String,
      required: function() {
        return this.type == 'dropdown';
      },
    }],
  }],
  createdBy: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Service = model('Service', serviceSchema);

export default Service;
