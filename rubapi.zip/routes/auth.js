import { Router } from 'express';
const authRoutes = Router();
import  login from '../controllers/auth';

authRoutes.post('/login', login);

export default authRoutes;
